<div class="sb-slidebar sb-left">
  <aside class="sb-widget">
  <div class="sb-widget-header">
    <h3 class="sb-widget-title"></h3>
  </div>
  <ul class="sb-menu">
    <li><a href="#Who">Who</a></li>
    <li><a href="#What">What</a></li>
    <li><a href="#Why">Why</a></li>
    <li><a href="#How">How</a></li>
  </ul>
  <div class="sidebar-text">Text</div>
</div>