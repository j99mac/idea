 <p class="pull-right"><a href="#">Back to top</a></p>
       <p> &copy; Sub Title</p> 